"use client";

import { useEffect } from "react";

export function DevToolsBlocker() {
    // Right-click blocking disabled - feature removed
    return null;
}
