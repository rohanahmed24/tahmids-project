"use client";

import { useEffect } from "react";

export function SecureSite() {
    // Right-click and dev tools blocking disabled - feature removed
    return null;
}
